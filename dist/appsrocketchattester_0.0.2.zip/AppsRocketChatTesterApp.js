"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
const App_1 = require("@rocket.chat/apps-engine/definition/App");
const ExtendSlashcommand_1 = require("./slashcommands/ExtendSlashcommand");
class RocketChatTester extends App_1.App {
    constructor(info, logger, accessors) {
        super(info, logger, accessors);
    }
    async extendConfiguration(configuration) {
        configuration.slashCommands.provideSlashCommand(new ExtendSlashcommand_1.ExtendMessageCommand());
    }
}
exports.RocketChatTester = RocketChatTester;
