"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
const api_1 = require("@rocket.chat/apps-engine/definition/api");
const safeJsonParse_1 = require("../lib/safeJsonParse");
class SendMessageAsAppUserEndpoint extends api_1.ApiEndpoint {
    constructor() {
        super(...arguments);
        this.path = 'send-message-as-app-user';
    }
    async post(request, endpoint, read, modify, http, persis) {
        const { roomId = 'GENERAL' } = safeJsonParse_1.safeJsonParse(request.content) || {};
        const room = await read.getRoomReader().getById(roomId);
        if (!room) {
            return {
                status: 404,
                content: `Room "${roomId}" could not be found`,
            };
        }
        const messageBuilder = modify.getCreator().startMessage()
            .setText('Executing send-message-as-app-user test endpoint')
            .setRoom(room);
        const messageId = await modify.getCreator().finish(messageBuilder);
        return this.success(JSON.stringify({ messageId }));
    }
}
exports.SendMessageAsAppUserEndpoint = SendMessageAsAppUserEndpoint;
