"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
const ImageAttachment_1 = require("../ImageAttachment");
class ExtendMessageCommand {
    constructor() {
        this.command = 'extend-message';
        this.i18nParamsExample = '';
        this.i18nDescription = '';
        this.providesPreview = false;
    }
    async executor(context, read, modify, http, persis) {
        var messageId = await this.sendMessage(context, modify, 'Sending one message!');
    }
    async sendMessage(context, modify, message) {
        const messageStructure = modify.getCreator().startMessage();
        const sender = context.getSender();
        const room = context.getRoom();
        const value = 1;
        const img = new ImageAttachment_1.ImageAttachment('https://open.rocket.chat/images/logo/logo.svg');
        console.log("MENSAGEM CRIADA!!!");
        messageStructure
            .setSender(sender)
            .setRoom(room)
            .setText(message)
            .addAttachment(img);
        messageStructure.addCustomField('key', 2);
        return (await modify.getCreator().finish(messageStructure));
    }
}
exports.ExtendMessageCommand = ExtendMessageCommand;
