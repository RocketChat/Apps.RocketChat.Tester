"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
const ImageAttachment_1 = require("../ImageAttachment");
class ExtendMessageCommand {
    constructor() {
        this.command = 'extend-message';
        this.i18nParamsExample = '';
        this.i18nDescription = '';
        this.providesPreview = false;
    }
    async executor(context, read, modify, http, persis) {
        const messageId = await this.sendMessage(context, modify, 'Sending a message!');
        const messageExtender = await this.getMessageExtender(context, modify, messageId);
        const value = 1;
        const img = new ImageAttachment_1.ImageAttachment('https://open.rocket.chat/images/logo/logo.svg');
        messageExtender.addCustomField('key', value);
        messageExtender.addAttachment(img);
        await modify.getExtender().finish(messageExtender);
    }
    async sendMessage(context, modify, message) {
        const messageStructure = modify.getCreator().startMessage();
        const sender = context.getSender();
        const room = context.getRoom();
        messageStructure
            .setSender(sender)
            .setRoom(room)
            .setText(message);
        return (await modify.getCreator().finish(messageStructure));
    }
    async getMessageExtender(context, modify, messageId) {
        const sender = context.getSender();
        return modify.getExtender().extendMessage(messageId, sender);
    }
}
exports.ExtendMessageCommand = ExtendMessageCommand;
