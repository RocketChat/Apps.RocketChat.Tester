"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
const ImageAttachment_1 = require("../ImageAttachment");
const Message_1 = require("../Message");
class ExtendMessageCommand {
    constructor() {
        this.command = 'extend-message';
        this.i18nParamsExample = '';
        this.i18nDescription = '';
        this.providesPreview = false;
    }
    async executor(context, read, modify, http, persis) {
        var messageId = await this.sendMessage(context, modify, 'Sending a message!');
    }
    async sendMessage(context, modify, message) {
        const messageStructure = modify.getCreator().startMessage();
        const sender = context.getSender();
        const room = context.getRoom();
        const value = 1;
        const img = new ImageAttachment_1.ImageAttachment('https://open.rocket.chat/images/logo/logo.svg');
        const msg = new Message_1.Message(sender, room, message);
        messageStructure.setData(msg);
        msg.addCustomField('key', value);
        msg.addAttachment(img);
        return (await modify.getCreator().finish(messageStructure));
    }
}
exports.ExtendMessageCommand = ExtendMessageCommand;
