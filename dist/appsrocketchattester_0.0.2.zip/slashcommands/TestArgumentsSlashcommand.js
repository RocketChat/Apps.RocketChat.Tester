"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
class TestArgumentsSlashcommand {
    constructor() {
        this.command = 'test-with-arguments';
        this.i18nParamsExample = 'test_arguments_command_example';
        this.i18nDescription = 'test_arguments_command_description';
        this.providesPreview = false;
    }
    async executor(context, read, modify, http, persis) {
        const room = context.getRoom();
        const args = context.getArguments();
        const messageBuilder = modify.getCreator().startMessage()
            .setText(`Slashcommand 'test-with-arguments' successfully executed with arguments: ${args.map((arg) => `"${arg}"`)}`)
            .setRoom(room);
        await modify.getCreator().finish(messageBuilder);
    }
}
exports.TestArgumentsSlashcommand = TestArgumentsSlashcommand;
