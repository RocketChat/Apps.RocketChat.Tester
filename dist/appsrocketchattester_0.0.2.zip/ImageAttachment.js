"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
class ImageAttachment {
    constructor(imgUrl) {
        this.imageUrl = imgUrl;
    }
    setImage(imgUrl) {
        this.imageUrl = imgUrl;
    }
}
exports.ImageAttachment = ImageAttachment;
