"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
class Message {
    constructor(sender, room, text) {
        this.sender = sender;
        this.room = room;
        this.text = text;
        if (!Array.isArray(this.attachments)) {
            this.attachments = new Array();
        }
    }
    addCustomField(key, value) {
        if (!this.customFields) {
            this.customFields = {};
        }
        if (this.customFields[key]) {
            throw new Error(`The message already contains a custom field by the key: ${key}`);
        }
        this.customFields[key] = value;
    }
    addAttachment(attachment) {
        this.attachments.push(attachment);
        return this;
    }
}
exports.Message = Message;
