"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
class TestSlashcommand {
    constructor() {
        this.command = 'test-simple';
        this.i18nParamsExample = 'test_command_example';
        this.i18nDescription = 'test_command_description';
        this.providesPreview = false;
    }
    async executor(context, read, modify, http, persis) {
        const room = context.getRoom();
        const messageBuilder = modify.getCreator().startMessage()
            .setText(`Slashcommand 'test-simple' successfully executed`)
            .setRoom(room);
        await modify.getCreator().finish(messageBuilder);
    }
}
exports.TestSlashcommand = TestSlashcommand;
