"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
const api_1 = require("@rocket.chat/apps-engine/definition/api");
const App_1 = require("@rocket.chat/apps-engine/definition/App");
const SendMessageAsAppUser_1 = require("./endpoints/SendMessageAsAppUser");
const SendMessageAsUser_1 = require("./endpoints/SendMessageAsUser");
const TestArgumentsSlashcommand_1 = require("./slashcommands/TestArgumentsSlashcommand");
const TestSlashcommand_1 = require("./slashcommands/TestSlashcommand");
class RocketChatTester extends App_1.App {
    constructor(info, logger, accessors) {
        super(info, logger, accessors);
    }
    async extendConfiguration(configuration) {
        configuration.api.provideApi({
            visibility: api_1.ApiVisibility.PUBLIC,
            security: api_1.ApiSecurity.UNSECURE,
            endpoints: [
                new SendMessageAsAppUser_1.SendMessageAsAppUserEndpoint(this),
                new SendMessageAsUser_1.SendMessageAsUserEndpoint(this),
            ],
        });
        configuration.slashCommands.provideSlashCommand(new TestSlashcommand_1.TestSlashcommand());
        configuration.slashCommands.provideSlashCommand(new TestArgumentsSlashcommand_1.TestArgumentsSlashcommand());
    }
}
exports.RocketChatTester = RocketChatTester;
