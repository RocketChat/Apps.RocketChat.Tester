"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
const accessors_1 = require("@rocket.chat/apps-engine/definition/accessors");
const api_1 = require("@rocket.chat/apps-engine/definition/api");
const safeJsonParse_1 = require("../lib/safeJsonParse");
class SendMessageAsUserEndpoint extends api_1.ApiEndpoint {
    constructor() {
        super(...arguments);
        this.path = 'send-message-as-user';
    }
    async post(request, endpoint, read, modify, http, persis) {
        const { roomId = 'GENERAL' } = safeJsonParse_1.safeJsonParse(request.content) || {};
        const room = await read.getRoomReader().getById(roomId);
        if (!room) {
            return {
                status: accessors_1.HttpStatusCode.NOT_FOUND,
                content: `Room "${roomId}" could not be found`,
            };
        }
        const { username } = request.query;
        const user = await read.getUserReader().getByUsername(username);
        if (!user) {
            return {
                status: accessors_1.HttpStatusCode.NOT_FOUND,
                content: `User with username "${username}" could not be found`,
            };
        }
        const messageBuilder = modify.getCreator().startMessage()
            .setText('Executing send-message-as-user test endpoint')
            .setRoom(room)
            .setSender(user);
        const messageId = await modify.getCreator().finish(messageBuilder);
        return this.success(JSON.stringify({ messageId }));
    }
}
exports.SendMessageAsUserEndpoint = SendMessageAsUserEndpoint;
